package com.cg.eis.service;
import com.cg.eis.bean.*;
public class Service {
	Employee obj;
	interface EmployeeService
	{
		public abstract void setEmployeeDetails(Employee obj);
		public abstract void insuranceScheme();
		public abstract void getEmployeDetails();
	}

	 class B implements EmployeeService
	{

		private Employee obj;

		@Override
		public void setEmployeeDetails(Employee obj) {
			this.obj=obj;
			
			
		}

		@Override
		public void insuranceScheme() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void getEmployeDetails() {
			// TODO Auto-generated method stub
			
		}
		
		
	}
}
