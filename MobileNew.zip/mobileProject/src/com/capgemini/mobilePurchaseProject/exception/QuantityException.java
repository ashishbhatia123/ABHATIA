package com.capgemini.mobilePurchaseProject.exception;

public class QuantityException extends Exception {

	QuantityException(String s)
	{
		super(s);
	}
}
