package com.capgemini.mobilePurchaseProject.exception;

public class availabilityException extends Exception {

	availabilityException(String s)
	{
		super(s);
	}
}
