package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;

public interface IProductService {
public abstract Product getProductDetail(int productCode) ;






}
